# SQE Studio M18 - Automatic Test

Runtime: 0.1.1.dev74
Selected: targeted, http, field_compare, em_convergence
Automatic prerequisites: integrity

## Current-run test outcomes (excluded tests never count as passed)

| Test | Status | Seconds |
|---|---|---|
| Source, contracts and cycle identity | PASS | 12.0 |
| Integration, provenance and negative tests | PASS | 59.609 |
| Saved project / authenticated HTTP workflow | PASS | 2.813 |
| Full portable software regression | SKIPPED_BY_PLAN | - |
| Real browser workflow | SKIPPED_BY_PLAN | - |
| Native Quantum Metal / GDS | SKIPPED_BY_PLAN | - |
| Native quantum basis curves and references | SKIPPED_BY_PLAN | - |
| Native Josephson linear / harmonic balance | SKIPPED_BY_PLAN | - |
| Upstream SQDMetal / VTK reader compatibility (no Palace) | SKIPPED_BY_PLAN | - |
| VTK cross-mesh sampling / analytic complex MAC (no Palace) | PASS | 15.328 |
| Palace single-mesh smoke / field diagnostics | SKIPPED_BY_PLAN | - |
| Palace two-mesh fields and scalar diagnostics | BLOCKED | 715.062 |
| Fresh wheel and isolated HTTP installation | SKIPPED_BY_PLAN | - |

Native execution, basis stability and literature comparison are separate substeps.
Physical qualification NOT ESTABLISHED; fabrication HOLD.
Share this original numbered ZIP. No user projects or raw native fields are included.
Cancellation takes effect after the current bounded task.
Compare common task scope; changing the selection is not scientific progress.
