# SQE Studio — laptop integrated EDA qualification

**Result: BLOCKED_NOT_RELEASE_CANDIDATE**
Profile: quick. PASS 4 · FAIL 0 · BLOCKED 12.
This report is local test evidence, not an independent scientific certification.

## Python environment
Active interpreter: 3.13.5
Managed scientific interpreter connected: False
Ready environments found: unknown
Incomplete environments found: unknown
If an earlier installation exists but is not connected, use the desktop Reconnect button.

| Gate | Result | Why / next step |
|---|---|---|
| source_integrity | PASS | See sanitized log |
| python_compile | PASS | See sanitized log |
| javascript_syntax | PASS | See sanitized log |
| integrated_regression | PASS | See sanitized log |
| browser_real_http | BLOCKED | Not executed in Quick profile |
| browser_deep_acceptance | BLOCKED | Browser smoke not passed, pytest unavailable or Quick profile |
| source_wheel_build | BLOCKED | Not executed in Quick profile |
| installed_wheel | BLOCKED | Not executed in Quick profile |
| installed_assets | BLOCKED | Not executed in Quick profile |
| native_quantum_metal | BLOCKED | Not executed in Quick profile |
| native_scqubits | BLOCKED | Not executed in Quick profile |
| native_josephson_circuits | BLOCKED | Not executed in Quick profile |
| native_em_design_loop | BLOCKED | Automated unattended convergence cannot waive physical material/port/mesh reviews; attach completed revision-bound runs for expert assessment |
| em_quantum_bridge | BLOCKED | Versioned reviewed EPR quantization edge is not implemented |
| geometry_optimization | BLOCKED | General multi-engine geometry feedback optimization not implemented |
| foundry_release | BLOCKED | Independent validation and foundry signoff not provided |

## Interpretation
PASS = test really executed and its stated software/native assertion passed.
BLOCKED = missing dependency, omitted profile, unavailable acceptance, or unimplemented scientific edge; NOT a pass.
FAIL = an executed test, build or verification reported a problem.
Native calculation alone does not imply experimental validation. No fixture values are presented as real EM output.
User project data, stored tokens, cookies, native designs and home workspace were not collected.
Logs are size-limited and best-effort redacted; inspect the archive before sharing.

## Path to RC
Clear FAIL gates, then reproduce real QDesign/GDS, Palace mesh/deck/solve and convergence on reviewed physical studies,
verify real browser installation on the target OS, qualify EM→quantum and RF interfaces,
and obtain independent validation and release approvals. Fabrication remains HOLD.

