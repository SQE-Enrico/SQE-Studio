# SQE Studio — native EM qualification (research reference)

Result: **BLOCKED_NOT_RELEASE_CANDIDATE**
PASS: 9 / FAIL: 0 / BLOCKED: 1

This runs the unmodified production A02/A03 worker on a temporary reference snapshot.
Operator-reviewed assumptions are EXPLORATORY; no foundry or independent validation.
No personal designs, material databases, original mesh or full field data are collected.

| Stage | Status | Interpretation |
|---|---|---|
| explicit_reference_review | PASS | Fixed research-only software-test assumptions loaded; no human material review or fabrication approval |
| native_em_toolchain | PASS | Required modules are present; successful import/mesh is not yet proven |
| results_screen_native_palace_solve | PASS | Production Results scalar readers accepted verified real native tables; not scientific qualification |
| mesh_and_deck | PASS | Mesh and deck verified inside the SAME native solve worker; redundant deck-only worker omitted |
| native_palace_solve | PASS | Native worker returned a hash-verified manifest; scientific review still required |
| results_screen_native_palace_refinement | PASS | Production Results scalar readers accepted verified real native tables; not scientific qualification |
| native_palace_refinement | PASS | Native worker returned a hash-verified manifest; scientific review still required |
| results_cross_run_comparison | PASS | Native mode-index frequency/Q/port deltas checked with production comparison logic; identity unresolved |
| upstream_field_correlation | PASS | Discrete visualization statistic only; no physical mode identity or mesh convergence |
| mesh_convergence | BLOCKED | Numeric trend recorded; field overlap and expert mode identity unavailable |

MPI ranks: 2 (1 OpenMP thread per rank). Speedup is not guaranteed.
Unverified partial eig.csv and phase diagnostics may be included after failure; NEVER solver acceptance.
Data: QUALIFICATION.json and native/* manifest summaries (SHA-256 for actual files).
Mesh and large solver outputs remain in the temporary workspace and are deleted.
Third-mesh memory is a conservative PRE-FLIGHT estimate only; WSL usage is NOT OS-enforced.
Solver-index matching is not verified field-overlap mode identity.
A successful native run is NOT independently validated or qualified as a device design.
Fabrication remains HOLD.

